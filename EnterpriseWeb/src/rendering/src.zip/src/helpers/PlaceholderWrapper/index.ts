export { default as PlaceholderWrapper } from './PlaceholderWrapper';
export type { PlaceholderComponentProps } from '@sitecore-jss/sitecore-jss-react/types/components/Placeholder';
