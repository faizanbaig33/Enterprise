const defaultData = {
  field: {},
};

export const noContent = {
  name: 'jss-main',
  rendering: {},
  field: {},
};

export default defaultData;
