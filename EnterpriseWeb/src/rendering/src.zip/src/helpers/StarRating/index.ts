export { default as StarRating } from './StarRating';
export type { StarRatingProps } from './StarRating';
