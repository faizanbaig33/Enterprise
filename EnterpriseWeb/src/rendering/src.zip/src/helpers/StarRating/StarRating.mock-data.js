const defaultData = {
  reviewStars: 4.3,
};

export default defaultData;
