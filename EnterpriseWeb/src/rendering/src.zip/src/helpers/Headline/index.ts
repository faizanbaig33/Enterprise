export { default as Headline } from './Headline';
export type { HeadlineProps } from './Headline';
