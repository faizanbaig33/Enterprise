export { default as RichTextWrapper } from './RichTextWrapper';
export type { RichTextProps } from '@sitecore-jss/sitecore-jss-react';
