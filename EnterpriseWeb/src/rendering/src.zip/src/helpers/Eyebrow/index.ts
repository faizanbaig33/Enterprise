export { default as Eyebrow } from './Eyebrow';
export type { EyebrowProps } from './Eyebrow';
