export { SliderWrapper } from './SliderWrapper';
