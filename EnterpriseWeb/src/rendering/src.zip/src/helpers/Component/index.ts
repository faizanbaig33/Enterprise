export { default as Component } from './Component';
