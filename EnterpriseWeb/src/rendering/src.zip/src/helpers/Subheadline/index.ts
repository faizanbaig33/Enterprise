export { default as Subheadline } from './Subheadline';
export type { SubheadlineProps } from './Subheadline';
