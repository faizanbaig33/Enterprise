export { default as ImageToggleWrapper } from './ImageToggleWrapper';
