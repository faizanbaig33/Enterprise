const defaultData = {
  fields: {
    body: {
      value: 'Vivamus integer non suscipit taciti mus <a rel="noopener noreferrer" href="https://www.lipsum.com/" target="_blank">amet</a> etiam at primis tempor sagittis sit, euismod libero <br/><ul><li>Test 1</li><li>Test 2</li></ul> <br/><br/> facilisi aptent elementum felis blandit cursus gravida sociis erat ante, eleifend lectus nullam dapibus netus feugiat curae curabitur est ad. Massa curae fringilla porttitor quam sollicitudin iaculis aptent leo ligula euismod dictumst, orci penatibus mauris eros etiam praesent erat volutpat posuere hac. Metus fringilla nec ullamcorper odio aliquam lacinia conubia mauris tempor, etiam ultricies proin quisque lectus sociis id tristique, integer phasellus taciti pretium adipiscing tortor sagittis ligula.',
    },
  },
  // classes: 'w-full p-2'
};

export default defaultData;
