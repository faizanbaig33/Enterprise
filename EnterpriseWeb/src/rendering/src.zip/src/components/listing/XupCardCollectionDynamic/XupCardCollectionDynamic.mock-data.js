const defaultData = {
  uid: '6078052e-6897-44f1-9915-7243aedc0fc4',
  componentName: 'XupCardCollectionDynamic',
  dataSource:
    '/sitecore/content/AndersenCorporation/AndersenWindows/AndersenWindows/Home/Components/Xup-Dynamic/Data/Xup Card Collection Dynamic - Photos',
  rendering: {
    componentName: 'XupCardCollectionDynamic',
    dataSource:
      '/sitecore/content/AndersenCorporation/AndersenWindows/AndersenWindows/Home/Components/Xup-Dynamic/Data/Xup Card Collection Dynamic - Photos',
  },
  fields: {
    alignment: {
      id: 'ed4b79ff-078b-47e0-8374-d30cd00224c9',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Alignment/Center',
      name: 'Center',
      displayName: 'Center',
      fields: {
        Value: {
          value: 'center',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    cardsPerRow: {
      id: '27348208-ad11-47ef-8138-4262fb5369d2',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Number-of-Cards/4',
      name: '4',
      displayName: '4',
      fields: {
        Value: {
          value: '4',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    cardStyle: {
      id: 'f1907a37-9ad5-453b-9db6-a94d3b2b477b',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Grid-Layout-Style/Result-with-Image',
      name: 'Result with Image',
      displayName: 'Result with Image',
      fields: {
        Value: {
          value: 'result-with-image',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    noResultsText: {
      value: 'Sorry! No results found',
    },
    numberOfCards: {
      value: null,
    },
    componentSpacing: null,
    sectionId: {
      value: '',
    },
    headlineText: {
      value: 'Component headline goes here',
    },
    superscriptCTA: {
      value: {
        href: '',
      },
    },
    headlineLevel: {
      id: '0f556f3a-bbad-4aa5-952d-b79003b39cd6',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Foundation/EnterpriseWeb/Enums/Headline-Levels/Heading-2',
      name: 'Heading 2',
      displayName: 'Heading 2',
      fields: {
        Value: {
          value: 'h2',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    body: {
      value:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    },
    cta1Icon: {
      id: '50590edc-7ea7-4436-9a3e-701c87a07db2',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Foundation/EnterpriseWeb/Enums/Icons/Arrow',
      name: 'Arrow',
      displayName: 'Arrow',
      fields: {
        Value: {
          value: 'arrow',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    cta1Link: {
      value: {
        href: '/',
        text: 'Call to Action',
        anchor: '',
        linktype: 'internal',
        class: '',
        title: '',
        querystring: '',
        id: '{7FB335D2-8E99-458E-9EF9-562A78CCB821}',
      },
    },
    cta1Modal: null,
    cta1ModalLinkText: {
      value: '',
    },
    cta1Style: {
      id: 'dd818850-ec95-4d32-9774-7cc8173e277b',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Foundation/EnterpriseWeb/Enums/CTA-Styles/Link',
      name: 'Link',
      displayName: 'Link',
      fields: {
        Value: {
          value: 'link',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    mobileDisplayStyle: {
      id: '34247fd8-fb45-4ff2-99f1-4956eaa9a4ee',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Display-Style/Horizontal-Scroll',
      name: 'Horizontal Scroll',
      displayName: 'Horizontal Scroll',
      fields: {
        Value: {
          value: 'horizontal-scroll',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    desktopDisplayStyle: {
      id: '98be30e0-6704-4e1c-827e-2f336f669190',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Display-Style/Grid',
      name: 'Grid',
      displayName: 'Grid',
      fields: {
        Value: {
          value: 'grid',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    queryPipeline: {
      value: 'default',
    },
    searchHub: {
      value: 'search',
    },
    sortDirection: {
      id: 'c42d2a22-7100-4467-97e9-795e0e6de342',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Sort-Direction/Ascending',
      name: 'Ascending',
      displayName: 'Ascending',
      fields: {
        Value: {
          value: 'ascending',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    sortField: null,
    sortType: {
      id: '3616dca7-4a65-478a-84d3-0e6dd9c5c7a5',
      url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Sort-Type/Date',
      name: 'Date',
      displayName: 'Date',
      fields: {
        Value: {
          value: 'date',
        },
      },
      templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
      templateName: 'Enum',
    },
    filterExpression: {
      value: '@sc_templateid==6AF8B67C11374B57A0E49EEEB1DFCCFA',
    },
    eventZone: {
      value: '',
    },
    eventName: {
      value: '',
    },
    eventType: {
      value: '',
    },
    children: [
      {
        id: '0e62501a-95be-4cbe-bb16-d4de76d3a691',
        displayName: 'Result Item',
        name: 'Result Item',
        templateId: 'cc77e3e9-19da-456b-8058-b893b285d626',
        templateName: 'Result Item',
        url: '/Components/Xup-Dynamic/result-with-image/Data/Xup-Card-Collection-Dynamic---Results-with-Image/Result-Item',
        fields: {
          ctaText: {
            value: 'Read More',
          },
          descriptionField: {
            id: '0cbb3c18-b35b-43d5-a199-3b2636bc8cec',
            url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Fields/Site-Search-Description',
            name: 'Site Search Description',
            displayName: 'Site Search Description',
            fields: {
              Value: {
                value: 'ew_sitesearchdescription',
              },
            },
            templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
            templateName: 'Enum',
          },
          eyebrowField: {
            id: 'bd539482-0573-41ba-93d4-c7bf4b8f61ff',
            url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Fields/Site-Search-Eyebrow',
            name: 'Site Search Eyebrow',
            displayName: 'Site Search Eyebrow',
            fields: {
              Value: {
                value: 'ew_eyebrow',
              },
            },
            templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
            templateName: 'Enum',
          },
          headingField: {
            id: '8ebd6f25-bc4a-44f8-a119-e653f3a54b03',
            url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Fields/Site-Search-Headline',
            name: 'Site Search Headline',
            displayName: 'Site Search Headline',
            fields: {
              Value: {
                value: 'ew_sitesearchheadline',
              },
            },
            templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
            templateName: 'Enum',
          },
          subHeadingField: {
            id: 'de8ba85a-cb1e-4fc3-bb05-09a95ed1a868',
            url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Fields/Site-Search-Topic',
            name: 'Site Search Topic',
            displayName: 'Site Search Topic',
            fields: {
              Value: {
                value: 'ew_sitesearchtopic',
              },
            },
            templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
            templateName: 'Enum',
          },
          thumbnailImageField: {
            id: '7ef6aca2-f90c-4cfc-8157-d2faeec38cdb',
            url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Fields/Site-Search-Image',
            name: 'Site Search Image',
            displayName: 'Site Search Image',
            fields: {
              Value: {
                value: 'ew_sitesearchimage',
              },
            },
            templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
            templateName: 'Enum',
          },
          imageField: null,
          relatedPagesField: null,
          titleField: null,
          resultType: [
            {
              id: '061b7069-2de9-4afd-a678-3aeac17c201e',
              url: 'http://localhost/sitecore/login/sitecore/system/Settings/Feature/EnterpriseWeb/Enums/Search/Page-Types/Photo',
              name: 'Photo',
              displayName: 'Photo',
              fields: {
                Value: {
                  value: '2AC3A2582F0A4081BB8EF00E281D4311',
                },
              },
              templateId: 'd2923fee-da4e-49be-830c-e27764dfa269',
              templateName: 'Enum',
            },
          ],
        },
      },
    ],
  },
};

export default defaultData;
