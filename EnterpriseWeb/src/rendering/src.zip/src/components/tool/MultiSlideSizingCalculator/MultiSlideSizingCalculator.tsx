// Global
import { Feature } from 'src/.generated/Feature.EnterpriseWeb.model';
import { useTheme } from 'lib/context/ThemeContext';
import { withDatasourceCheck } from '@sitecore-jss/sitecore-jss-nextjs';
// Components
import { Component } from 'src/helpers/Component';
import { MultiSlideSizingCalculatorTheme } from './MultiSlideSizingCalculator.theme';
/*
import classNames from 'classnames';

import { useForm } from 'react-hook-form';
import React, { ChangeEvent, useState } from 'react';
import ModalWrapper from 'src/helpers/ModalWrapper/ModalWrapper';
import { SvgIcon } from 'src/helpers/SvgIcon';
import { RichTextWrapper } from 'src/helpers/RichTextWrapper';
import { useExperienceEditor } from 'lib/utils'; */

export type MultiSlideSizingCalculatorProps =
  Feature.EnterpriseWeb.Components.Tool.MultiSlideSizingCalculatorProps;

const MultiSlideSizingCalculator = (props: MultiSlideSizingCalculatorProps): JSX.Element => {
  return (
    <Component variant="lg" dataComponent="tool/multislidesizingcalculator" {...props}>
      MultiSlideSizingCalculator
    </Component>
  );
};

export default withDatasourceCheck()<MultiSlideSizingCalculatorProps>(MultiSlideSizingCalculator);
