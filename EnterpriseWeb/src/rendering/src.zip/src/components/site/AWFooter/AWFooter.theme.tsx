// Lib
import { ThemeFile } from 'lib/context/ThemeContext';

export const AWFooterTheme: ThemeFile = {
  aw: {
    classes: {},
  },
  rba: {
    classes: {},
  },
};
