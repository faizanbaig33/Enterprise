// Lib
import { ThemeFile } from 'lib/context/ThemeContext';

export const AWHeaderTheme: ThemeFile = {
  aw: {
    classes: {},
  },
  rba: {
    classes: {},
  },
};
